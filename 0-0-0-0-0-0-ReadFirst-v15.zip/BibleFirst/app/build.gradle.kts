plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// The signing key is NOT stored in the project. GitHub puts it here from
// the repo's secret settings (RF_KEYSTORE_B64 and RF_PASSWORD) at build time.
val rfKeystore: String? = System.getenv("RF_KEYSTORE")
val rfPassword: String? = System.getenv("RF_PASSWORD")

android {
    namespace = "com.biblefirst"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.readfirst.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 15
        versionName = "2.1"
    }

    signingConfigs {
        create("readfirst") {
            if (rfKeystore != null && rfPassword != null) {
                storeFile = file(rfKeystore)
                storePassword = rfPassword
                keyAlias = "readfirst"
                keyPassword = rfPassword
            }
        }
    }

    buildTypes {
        debug {
            if (rfKeystore != null && rfPassword != null) {
                signingConfig = signingConfigs.getByName("readfirst")
            }
        }
        release {
            isMinifyEnabled = false
            if (rfKeystore != null && rfPassword != null) {
                signingConfig = signingConfigs.getByName("readfirst")
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
