package com.biblefirst

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.time.LocalDate

/** First-run guided setup, then the settings / home screen. */
class MainActivity : Activity() {

    private lateinit var root: LinearLayout
    private var showAllApps = false
    private var step1Badge: TextView? = null
    private var startBtn: Button? = null

    private fun Int.dp() = Ui.dp(this@MainActivity, this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.styleWindow(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20.dp(), 36.dp(), 20.dp(), 32.dp())
        }
        setContentView(ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isFillViewport = true
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        if (Prefs.setupDone(this)) Reminder.schedule(this)
        render()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        render()
    }

    private fun render() {
        root.removeAllViews()
        when {
            !Prefs.setupDone(this) -> renderSetup()
            choosingStart -> renderStartChoice()
            else -> renderHome()
        }
    }

    // ---------- Checks and shortcuts ----------

    private fun accessibilityOn(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains("$packageName/")
    }

    private fun notificationsOn(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && !notificationsOn()) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    /** Goes straight to Read First's own switch where the phone allows it. */
    private fun openAccessibility() {
        Prefs.arm(this) // Settings is blocked while locked, except when opened from here.
        val cn = ComponentName(this, LockService::class.java).flattenToString()
        val direct = Intent("android.settings.ACCESSIBILITY_DETAILS_SETTINGS")
            .putExtra(Intent.EXTRA_COMPONENT_NAME, cn)
        try {
            startActivity(direct)
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    private fun openAppInfo() {
        Prefs.arm(this)
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun launcherApps(): List<Pair<String, String>> {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
    }

    private fun looksLikeBible(pkg: String, name: String): Boolean {
        val n = name.lowercase()
        return pkg in BIBLE_PKGS || n.contains("bible") || n.contains("jw library") || n.contains("scripture")
    }

    // ---------- First-run setup: 3 steps ----------

    private fun renderSetup() {
        val apps = launcherApps()
        Prefs.setPlan(this, Prefs.plan(this)) // make sure a starting place is saved
        if (!Prefs.bibleAutoPicked(this)) {
            val found = apps.filter { looksLikeBible(it.first, it.second) }.map { it.first }
            if (found.isNotEmpty()) Prefs.setBibleApps(this, Prefs.bibleApps(this) + found)
            Prefs.setBibleAutoPicked(this)
        }

        // Back from Android's switch with it turned on: setup is finished.
        if (setupPending && accessibilityOn() && Prefs.bibleApps(this).isNotEmpty()) {
            finishSetup()
            return
        }

        root.addView(Ui.text(this, "Set up Read First", 28f, serif = true, bold = true))

        // When: days and start time
        val whenCard = Ui.card(this, 4)
        whenCard.addView(daysRow())
        whenCard.addView(Ui.divider(this))
        whenCard.addView(stepperRow("Lock starts at", "Each morning", hourLabel(Prefs.startHour(this)),
            { Prefs.setStartHour(this, Prefs.startHour(this) - 1); render() },
            { Prefs.setStartHour(this, Prefs.startHour(this) + 1); render() }))
        root.addView(whenCard, Ui.lp(this, 18))

        // Where to start reading
        val planCard = Ui.card(this)
        planCard.addView(Ui.text(this, "Start reading from", 17f, bold = true))
        planCard.addView(planChips(), Ui.lp(this, 10))
        root.addView(planCard, Ui.lp(this, 12))

        // Read it or listen to it
        val modeCard = Ui.card(this)
        modeCard.addView(Ui.text(this, "How would you like your reading?", 17f, bold = true))
        modeCard.addView(modeChips(), Ui.lp(this, 10))
        root.addView(modeCard, Ui.lp(this, 12))

        // Your Bible app, then any other apps (hidden until you ask for them)
        val chosen = Prefs.bibleApps(this).toMutableSet()
        val appsCard = Ui.card(this)
        appsCard.addView(Ui.text(this, "Apps you can use while locked", 17f, bold = true))
        appsCard.addView(Ui.text(this, "Phone, texts and maps always work.", 14f, Ui.MUTED), Ui.lp(this, 2))
        addAppChecks(appsCard, apps, chosen) { refreshSetup(chosen) }
        root.addView(appsCard, Ui.lp(this, 12))

        root.addView(
            Ui.text(this, "Read First only sees which app is open. Nothing leaves your phone.", 14f, Ui.MUTED),
            Ui.lp(this, 16)
        )

        // One button: accept, then Android asks to Allow.
        val start = Ui.button(this, "Accept and start", filled = true) {
            Prefs.setPrivacyAccepted(this)
            setupPending = true
            if (accessibilityOn()) finishSetup() else openAccessibility()
        }
        startBtn = start
        root.addView(start, Ui.lp(this, 12))

        // Only if Android blocked it the first time.
        if (setupPending && !accessibilityOn() && Build.VERSION.SDK_INT >= 33) {
            root.addView(Ui.link(this, "Android said \"restricted\"? Tap here", Ui.ACCENT_DARK) {
                android.widget.Toast.makeText(
                    this, "Tap ⋮ at the top right, then Allow restricted settings. Then come back.",
                    android.widget.Toast.LENGTH_LONG
                ).show()
                openAppInfo()
            }, Ui.lp(this, 6))
        }
        refreshSetup(chosen)
    }

    private var setupPending = false

    private var choosingStart = false

    private fun finishSetup() {
        setupPending = false
        Prefs.setEnabled(this, true)
        Prefs.setSetupDone(this, true)
        Reminder.schedule(this)
        requestNotifications()
        choosingStart = true
        render()
    }

    /** Last step of setup: begin today, or wait until tomorrow morning. */
    private fun renderStartChoice() {
        root.addView(Ui.text(this, "You're all set", 28f, serif = true, bold = true))
        root.addView(Ui.text(this, "When would you like to start?", 16f, Ui.BODY), Ui.lp(this, 6))


        root.addView(Ui.button(this, if (Prefs.listenMode(this)) "Start listening now" else "Start my reading now", filled = true,
            icon = if (Prefs.listenMode(this)) R.drawable.ic_listen else R.drawable.ic_book) {
            choosingStart = false
            Prefs.clearSkip(this)
            render()
            ReadingActivity.open(this)
        }, Ui.lp(this, 24))
        root.addView(Ui.text(this, "Your phone locks now until you finish today's reading.", 14f, Ui.MUTED),
            Ui.lp(this, 6))

        root.addView(Ui.button(this, "Start tomorrow", filled = false) {
            choosingStart = false
            Prefs.skipToday(this)
            render()
        }, Ui.lp(this, 20))
        root.addView(Ui.text(this, "Use your phone as normal today. The lock begins tomorrow morning.", 14f, Ui.MUTED),
            Ui.lp(this, 6))
    }

    private fun refreshSetup(chosen: Set<String>) {
        val ready = chosen.isNotEmpty()
        startBtn?.isEnabled = ready
        startBtn?.alpha = if (ready) 1f else 0.4f
        startBtn?.text = if (ready) "Accept and start" else "Tick your Bible app first"
    }

    private fun stepCard(num: Int, title: String, done: Boolean): Pair<LinearLayout, TextView> {
        val card = Ui.card(this)
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val badge = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 15f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        setBadge(badge, num, done)
        head.addView(badge, LinearLayout.LayoutParams(32.dp(), 32.dp()))
        head.addView(Ui.text(this, title, 17f, bold = true).apply { setPadding(12.dp(), 0, 0, 0) })
        card.addView(head)
        return card to badge
    }

    private fun setBadge(b: TextView, num: Int, done: Boolean) {
        b.text = if (done) "✓" else num.toString()
        b.setTextColor(if (done) Color.WHITE else Ui.ACCENT_DARK)
        b.background = Ui.shape(this, if (done) Ui.ACCENT else Ui.TINT, 16)
        b.contentDescription = if (done) "Step $num done" else "Step $num"
    }

    /**
     * The apps actually installed on this phone, with their icons.
     * Bible apps come first; every other app follows so people can tick what they need.
     */
    private fun addAppChecks(
        card: LinearLayout,
        apps: List<Pair<String, String>>,
        chosen: MutableSet<String>,
        onChange: () -> Unit
    ) {
        val bible = apps.filter { looksLikeBible(it.first, it.second) }
        val others = apps.filter { !looksLikeBible(it.first, it.second) }
        val expanded = showAllApps || bible.isEmpty()
        val shownOthers = if (expanded) others else others.filter { it.first in chosen }

        if (bible.isNotEmpty()) {
            card.addView(Ui.label(this, "Bible apps on this phone"), Ui.lp(this, 8))
            for (a in bible) card.addView(appRow(a.first, a.second, chosen, onChange))
        } else {
            card.addView(
                Ui.text(this, "No Bible app found. Tick the one you use below.", 14f, Ui.MUTED),
                Ui.lp(this, 8)
            )
        }
        if (shownOthers.isNotEmpty()) {
            card.addView(Ui.label(this, "Other apps on this phone"), Ui.lp(this, 14))
            for (a in shownOthers) card.addView(appRow(a.first, a.second, chosen, onChange))
        }
        if (others.isNotEmpty()) {
            card.addView(
                Ui.link(this, if (showAllApps) "Hide other apps" else "+ Add other apps (${others.size})", Ui.ACCENT_DARK) {
                    showAllApps = !showAllApps
                    render()
                },
                Ui.lp(this, 4, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
        }
    }

    /** One app: its real icon, its name, and a tick box. Tapping anywhere on the row ticks it. */
    private fun appRow(pkg: String, name: String, chosen: MutableSet<String>, onChange: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = 52.dp()
            isClickable = true
            isFocusable = true
        }
        val icon = ImageView(this).apply {
            try {
                setImageDrawable(packageManager.getApplicationIcon(pkg))
            } catch (e: Exception) {
                setImageDrawable(Ui.tint(this@MainActivity, R.drawable.ic_book, Ui.ACCENT))
            }
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        row.addView(icon, LinearLayout.LayoutParams(32.dp(), 32.dp()))
        row.addView(Ui.text(this, name, 16f, Ui.TEXT).apply { setPadding(12.dp(), 0, 8.dp(), 0) },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val box = CheckBox(this).apply {
            buttonTintList = ColorStateList.valueOf(Ui.ACCENT)
            isChecked = pkg in chosen
            contentDescription = name
            setOnCheckedChangeListener { _, on ->
                if (on) chosen += pkg else chosen -= pkg
                Prefs.setBibleApps(this@MainActivity, chosen)
                onChange()
            }
        }
        row.addView(box)
        row.setOnClickListener { box.isChecked = !box.isChecked }
        return row
    }

    // ---------- Home / settings ----------

    private fun renderHome() {
        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = ImageView(this).apply {
            setImageDrawable(Ui.tint(this@MainActivity, R.drawable.ic_book, Color.WHITE))
            background = Ui.shape(this@MainActivity, Ui.ACCENT, 14)
            scaleType = ImageView.ScaleType.CENTER
        }
        header.addView(logo, LinearLayout.LayoutParams(48.dp(), 48.dp()))
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12.dp(), 0, 0, 0)
        }
        // Hidden tester tools: press and hold the title.
        titles.addView(Ui.text(this, "Read First", 28f, serif = true, bold = true).apply {
            setOnLongClickListener {
                testerTools()
                true
            }
        })
        val status = when {
            !Prefs.enabled(this) -> "Lock is switched off"
            Prefs.doneToday(this) -> "Reading done today. Enjoy your day"
            !Prefs.isLockDay(this, LocalDate.parse(Prefs.dayKey(this))) -> "Day off today. No lock"
            Prefs.skippedToday(this) -> "Lock starts tomorrow morning"
            Prefs.overrideActive(this) -> "Emergency override is on"
            else -> "Lock is on until you've read"
        }
        titles.addView(Ui.text(this, status, 14f, Ui.ACCENT_DARK, bold = true))
        header.addView(titles)
        root.addView(header)

        // Stats
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        stats.addView(stat("${Prefs.streak(this)}", "day streak"))
        stats.addView(stat("${Prefs.points(this)}", "points"))
        stats.addView(stat("${Prefs.overrideCount(this)}", "overrides used"))
        root.addView(stats, Ui.lp(this, 20))

        // Today
        val next = Bible.label(this, Prefs.readingPos(this))
        if (Prefs.isLocked(this)) {
            root.addView(Ui.button(this, if (Prefs.listenMode(this)) "Listen to today's reading" else "Start today's reading", filled = true,
                icon = if (Prefs.listenMode(this)) R.drawable.ic_listen else R.drawable.ic_book) {
                ReadingActivity.open(this)
            }, Ui.lp(this, 16))
            root.addView(Ui.button(this, "I've finished my reading", filled = false, icon = R.drawable.ic_check) {
                CheckIn.show(this) { render() }
            }, Ui.lp(this, 10))
        } else {
            root.addView(Ui.button(this, "Keep reading: $next", filled = true, icon = R.drawable.ic_book) {
                ReadingActivity.open(this)
            }, Ui.lp(this, 16))
        }
        root.addView(Ui.text(this, "Next up: $next. You'll never read the same chapter twice.", 13f, Ui.MUTED).apply {
            gravity = Gravity.CENTER
        }, Ui.lp(this, 6))

        // Feed: what you've read
        root.addView(Ui.label(this, "Your reading"), Ui.lp(this, 22))
        root.addView(feedCard(), Ui.lp(this, 8))

        // Milestones
        root.addView(Ui.label(this, "Milestones"), Ui.lp(this, 22))
        root.addView(milestonesCard(), Ui.lp(this, 8))

        // App detection warning, if it has been switched off
        if (!accessibilityOn()) {
            val warn = Ui.card(this)
            warn.addView(Ui.text(this, "App detection is off", 16f, Ui.RED, bold = true))
            warn.addView(
                Ui.text(this, "The lock can't work until it's switched back on.", 14f, Ui.BODY),
                Ui.lp(this, 4)
            )
            warn.addView(Ui.button(this, "Turn on app detection", filled = true) { openAccessibility() }, Ui.lp(this, 10))
            root.addView(warn, Ui.lp(this, 16))
        }

        // Morning lock
        root.addView(Ui.label(this, "Morning lock"), Ui.lp(this, 22))
        val lock = Ui.card(this, 4)
        lock.addView(switchRow())
        lock.addView(Ui.divider(this))
        lock.addView(stepperRow("Starts at", "When your new day begins", hourLabel(Prefs.startHour(this)),
            { Prefs.setStartHour(this, Prefs.startHour(this) - 1); Reminder.schedule(this); render() },
            { Prefs.setStartHour(this, Prefs.startHour(this) + 1); Reminder.schedule(this); render() }))
        lock.addView(Ui.divider(this))
        lock.addView(stepperRow("Gentle reminder", "Before the lock starts", reminderLabel(Prefs.reminderMinutes(this)),
            { Prefs.setReminderMinutes(this, Prefs.reminderMinutes(this) - 15); Reminder.schedule(this); render() },
            {
                Prefs.setReminderMinutes(this, Prefs.reminderMinutes(this) + 15)
                requestNotifications(); Reminder.schedule(this); render()
            }))
        lock.addView(Ui.divider(this))
        lock.addView(daysRow())
        root.addView(lock, Ui.lp(this, 8))

        // Read or listen
        root.addView(Ui.label(this, "Your reading"), Ui.lp(this, 22))
        val modeCard = Ui.card(this)
        modeCard.addView(Ui.text(this, "Read it yourself, or have the phone read it aloud to you.", 14f, Ui.MUTED))
        modeCard.addView(modeChips(), Ui.lp(this, 10))
        root.addView(modeCard, Ui.lp(this, 8))

        // Apps
        root.addView(Ui.label(this, "Apps you can still use"), Ui.lp(this, 22))
        val appsCard = Ui.card(this, 12)
        appsCard.addView(
            Ui.text(this, "Phone, texts and maps always work. Tick your Bible app and anything else you need.", 14f, Ui.MUTED)
        )
        addAppChecks(appsCard, launcherApps(), Prefs.bibleApps(this).toMutableSet()) {}
        root.addView(appsCard, Ui.lp(this, 8))

        // Privacy
        root.addView(Ui.label(this, "Your privacy"), Ui.lp(this, 22))
        root.addView(privacyBox(), Ui.lp(this, 8))

        root.addView(Ui.link(this, "Run setup again", Ui.BODY) {
            Prefs.setSetupDone(this, false)
            render()
        }, Ui.lp(this, 12))
        root.addView(Ui.text(this, "Version ${appVersion()}", 12f, Ui.MUTED).apply {
            gravity = Gravity.CENTER
        }, Ui.lp(this, 4))
    }

    private fun appVersion(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: ""
    } catch (e: Exception) {
        ""
    }

    /** For testers only: reset today's reading and see what was last blocked. */
    private fun testerTools() {
        val last = Prefs.lastBlocked(this).ifEmpty { "nothing yet" }
        android.app.AlertDialog.Builder(this)
            .setTitle("Tester tools")
            .setMessage("Last app blocked: $last\n\nReset today clears today's reading so you can test the lock again.")
            .setPositiveButton("Reset today") { _, _ ->
                Prefs.clearDone(this)
                render()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    /** What the app can and can't see. Shown in setup (with consent) and in settings. */
    private fun privacyBox(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.shape(this@MainActivity, Ui.TINT, 14)
            setPadding(14.dp(), 12.dp(), 14.dp(), 12.dp())
        }
        box.addView(Ui.text(this, "What Read First can see", 15f, Ui.ACCENT_DARK, bold = true))
        val lines = listOf(
            "• Only the name of the app on screen, so it knows when to show the reading screen.",
            "• It can't see your messages, photos, passwords or anything you type.",
            "• Your journal stays on this phone. No account, no internet, nothing is sent anywhere."
        )
        for (l in lines) box.addView(Ui.text(this, l, 14f, Ui.BODY), Ui.lp(this, 6))
        return box
    }

    /** Badges for 3, 7, 14, 30, 50, 100 and 365 days, plus a share button. */
    private fun milestonesCard(): View {
        val card = Ui.card(this, 14)
        val best = Prefs.bestStreak(this)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        var row: LinearLayout? = null
        Prefs.MILESTONES.forEachIndexed { i, days ->
            if (i % 4 == 0) {
                row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                grid.addView(row, Ui.lp(this, if (i == 0) 0 else 8))
            }
            val earned = best >= days
            val badge = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = if (earned) Ui.shape(this@MainActivity, Ui.ACCENT, 14)
                else Ui.shape(this@MainActivity, Ui.CARD, 14, Ui.BORDER, 2)
                setPadding(4.dp(), 10.dp(), 4.dp(), 10.dp())
                contentDescription = "${CheckIn.badgeName(days)}, ${if (earned) "earned" else "not yet"}"
            }
            badge.addView(Ui.text(this, "$days", 20f, if (earned) Color.WHITE else Ui.MUTED, bold = true, serif = true).apply {
                gravity = Gravity.CENTER
            })
            badge.addView(Ui.text(this, "days", 12f, if (earned) Color.WHITE else Ui.MUTED).apply {
                gravity = Gravity.CENTER
            })
            row?.addView(badge, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = 3.dp()
                marginEnd = 3.dp()
            })
        }
        // Keep the last row's badges the same width as the others.
        val leftover = (4 - Prefs.MILESTONES.size % 4) % 4
        repeat(leftover) {
            row?.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f).apply {
                marginStart = 3.dp()
                marginEnd = 3.dp()
            })
        }
        card.addView(grid)

        val next = Prefs.MILESTONES.firstOrNull { it > best }
        card.addView(
            Ui.text(
                this,
                if (next == null) "Every badge earned. Amazing!"
                else "Next badge: ${CheckIn.badgeName(next)} at $next days.",
                14f, Ui.MUTED
            ),
            Ui.lp(this, 12)
        )
        val streak = Prefs.streak(this)
        if (streak > 0) {
            card.addView(Ui.button(this, "Share my $streak-day streak", filled = false) {
                ShareCard.share(this, streak)
            }, Ui.lp(this, 10))
        }
        return card
    }

    /** The last few days you read, newest first, with a link to the full journal. */
    private fun feedCard(): View {
        val card = Ui.card(this, 14)
        val entries = Prefs.journal(this).take(5)
        if (entries.isEmpty()) {
            card.addView(Ui.text(this, "Nothing yet. Your readings will show here.", 14f, Ui.MUTED))
        }
        val fmt = java.time.format.DateTimeFormatter.ofPattern("EEE d MMM", java.util.Locale.getDefault())
        entries.forEachIndexed { i, e ->
            if (i > 0) card.addView(Ui.divider(this), Ui.lp(this, 10).apply { height = 1.dp() })
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val date = try { LocalDate.parse(e.day).format(fmt) } catch (x: Exception) { e.day }
            val isToday = e.day == Prefs.dayKey(this)
            row.addView(Ui.label(this, if (isToday) "Today" else date))
            if (e.passage.isNotBlank()) row.addView(Ui.text(this, e.passage, 16f, Ui.TEXT, bold = true), Ui.lp(this, 2))
            if (e.thought.isNotBlank()) row.addView(Ui.text(this, e.thought, 15f, Ui.BODY, serif = true, italic = true), Ui.lp(this, 2))
            card.addView(row, Ui.lp(this, if (i == 0) 0 else 10))
        }
        if (entries.isNotEmpty()) {
            card.addView(Ui.link(this, "See my full journal", Ui.ACCENT_DARK) {
                startActivity(Intent(this, JournalActivity::class.java))
            }, Ui.lp(this, 4, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        return card
    }

    /** New Testament / Psalms / Beginning of the Bible. */
    private fun planChips(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val options = listOf(
            Bible.PLAN_NT to "New Testament",
            Bible.PLAN_PSALMS to "Psalms",
            Bible.PLAN_START to "Genesis"
        )
        val current = Prefs.plan(this)
        for ((key, name) in options) {
            val on = key == current
            col.addView(Button(this).apply {
                text = if (on) "✓  $name" else name
                isAllCaps = false
                textSize = 15f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(if (on) Color.WHITE else Ui.ACCENT_DARK)
                stateListAnimator = null
                background = if (on) Ui.shape(this@MainActivity, Ui.ACCENT, 24)
                else Ui.shape(this@MainActivity, Ui.CARD, 24, Ui.BORDER, 2)
                minWidth = 0
                minimumWidth = 0
                minHeight = 48.dp()
                minimumHeight = 48.dp()
                setPadding(16.dp(), 10.dp(), 16.dp(), 10.dp())
                contentDescription = name + if (on) ", chosen" else ""
                setOnClickListener {
                    Prefs.setPlan(this@MainActivity, key)
                    render()
                }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = 8.dp()
            })
        }
        return col
    }

    /** Read it / Listen to it. */
    private fun modeChips(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val listen = Prefs.listenMode(this)
        for ((isListen, name) in listOf(false to "Read it", true to "Listen to it")) {
            val on = isListen == listen
            row.addView(Button(this).apply {
                text = name
                isAllCaps = false
                textSize = 15f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(if (on) Color.WHITE else Ui.ACCENT_DARK)
                val ic = Ui.tint(this@MainActivity, if (isListen) R.drawable.ic_listen else R.drawable.ic_book,
                    if (on) Color.WHITE else Ui.ACCENT_DARK)
                ic?.setBounds(0, 0, 20.dp(), 20.dp())
                setCompoundDrawablesRelative(ic, null, null, null)
                compoundDrawablePadding = 8.dp()
                stateListAnimator = null
                background = if (on) Ui.shape(this@MainActivity, Ui.ACCENT, 24)
                else Ui.shape(this@MainActivity, Ui.CARD, 24, Ui.BORDER, 2)
                minWidth = 0
                minimumWidth = 0
                minHeight = 48.dp()
                minimumHeight = 48.dp()
                setPadding(12.dp(), 10.dp(), 12.dp(), 10.dp())
                contentDescription = name + if (on) ", chosen" else ""
                setOnClickListener {
                    Prefs.setListenMode(this@MainActivity, isListen)
                    render()
                }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = 4.dp()
                marginEnd = 4.dp()
            })
        }
        return row
    }

    /** Mon-Sun chips: which days the lock runs. */
    private fun daysRow(): View {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12.dp(), 12.dp(), 12.dp(), 12.dp())
        }
        wrap.addView(Ui.text(this, "Lock on these days", 16f, bold = true))
        wrap.addView(Ui.text(this, "Days off keep your streak going", 14f, Ui.MUTED))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val names = listOf("M", "T", "W", "T", "F", "S", "S")
        val full = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
        val on = Prefs.lockDays(this)
        for (d in 1..7) {
            val isOn = d in on
            row.addView(Button(this).apply {
                text = names[d - 1]
                textSize = 14f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(if (isOn) Color.WHITE else Ui.MUTED)
                stateListAnimator = null
                background = if (isOn) Ui.shape(this@MainActivity, Ui.ACCENT, 20)
                else Ui.shape(this@MainActivity, Ui.CARD, 20, Ui.BORDER, 2)
                contentDescription = "${full[d - 1]}, ${if (isOn) "lock on" else "day off"}"
                minWidth = 0
                minimumWidth = 0
                minHeight = 0
                minimumHeight = 0
                setPadding(0, 0, 0, 0)
                setOnClickListener {
                    Prefs.setLockDay(this@MainActivity, d, !isOn)
                    Reminder.schedule(this@MainActivity)
                    render()
                }
            }, LinearLayout.LayoutParams(0, 44.dp(), 1f).apply {
                marginStart = 2.dp()
                marginEnd = 2.dp()
            })
        }
        wrap.addView(row, Ui.lp(this, 10))
        return wrap
    }

    private fun stat(value: String, label: String): View {
        val box = Ui.card(this, 12)
        box.addView(Ui.text(this, value, 26f, Ui.ACCENT_DARK, bold = true, serif = true))
        box.addView(Ui.text(this, label, 13f, Ui.MUTED))
        box.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = 4.dp()
            marginEnd = 4.dp()
        }
        return box
    }

    private fun switchRow(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12.dp(), 12.dp(), 12.dp(), 12.dp())
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(Ui.text(this, "Lock each morning", 16f, bold = true))
        col.addView(Ui.text(this, "Until you mark your reading done", 14f, Ui.MUTED))
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        row.addView(Switch(this).apply {
            contentDescription = "Lock each morning"
            isChecked = Prefs.enabled(this@MainActivity)
            thumbTintList = ColorStateList(states, intArrayOf(Ui.ACCENT, Color.parseColor("#F1EFF5")))
            trackTintList = ColorStateList(states, intArrayOf(Ui.TINT, Color.parseColor("#C9C2D6")))
            setOnCheckedChangeListener { _, on ->
                Prefs.setEnabled(this@MainActivity, on)
                Reminder.schedule(this@MainActivity)
                render()
            }
        })
        return row
    }

    private fun stepperRow(title: String, sub: String, value: String, minus: () -> Unit, plus: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12.dp(), 12.dp(), 12.dp(), 12.dp())
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(Ui.text(this, title, 16f, bold = true))
        col.addView(Ui.text(this, sub, 14f, Ui.MUTED))
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(round("−", "Less", minus))
        row.addView(Ui.text(this, value, 15f, bold = true).apply {
            gravity = Gravity.CENTER
            minWidth = 72.dp()
        })
        row.addView(round("+", "More", plus))
        return row
    }

    private fun round(symbol: String, desc: String, onClick: () -> Unit) = Button(this).apply {
        text = symbol
        textSize = 20f
        setTextColor(Ui.TEXT)
        contentDescription = desc
        stateListAnimator = null
        setPadding(0, 0, 0, 0)
        background = Ui.shape(this@MainActivity, Ui.BG, 22, Color.parseColor("#DAD2E6"))
        minWidth = 0
        minimumWidth = 0
        minHeight = 0
        minimumHeight = 0
        layoutParams = LinearLayout.LayoutParams(44.dp(), 44.dp())
        setOnClickListener { onClick() }
    }

    private fun hourLabel(h: Int) = when {
        h == 0 -> "12:00 am"
        h < 12 -> "$h:00 am"
        else -> "12:00 pm"
    }

    private fun reminderLabel(m: Int) = if (m == 0) "Off" else "$m min"

    companion object {
        private val BIBLE_PKGS = setOf(
            "org.jw.jwlibrary.mobile",
            "com.sirma.mobile.bible.android",
            "com.olivetree.bible",
            "org.blueletterbible.blb"
        )
    }
}
