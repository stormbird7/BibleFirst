package com.biblefirst

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Telephony

/** Works out which apps may be used while the phone is locked. */
object AllowList {

    // Calls, texts, maps, alarms, keyboards and system pieces. Includes Samsung packages.
    private val known = setOf(
        // system
        "com.android.systemui",
        // "choose an app" pop-ups
        "android", "com.android.intentresolver",
        "com.google.android.permissioncontroller",
        "com.android.permissioncontroller",
        // calls
        "com.android.server.telecom", "com.android.phone", "com.android.incallui",
        "com.android.dialer", "com.google.android.dialer",
        "com.samsung.android.dialer", "com.samsung.android.incallui",
        "com.samsung.android.app.telephonyui",
        // texts
        "com.google.android.apps.messaging", "com.samsung.android.messaging", "com.android.mms",
        // contacts (needed to call or text someone)
        "com.samsung.android.app.contacts", "com.google.android.contacts", "com.android.contacts",
        // emergency
        "com.samsung.android.emergency", "com.android.emergency", "com.google.android.apps.safetyhub",
        // Samsung edge panel and screenshots
        "com.samsung.android.app.cocktailbarservice", "com.samsung.android.app.smartcapture",
        // maps
        "com.google.android.apps.maps",
        // alarms (so your morning alarm can still be turned off)
        "com.google.android.deskclock", "com.android.deskclock", "com.sec.android.app.clockpackage",
        // keyboards
        "com.samsung.android.honeyboard", "com.google.android.inputmethod.latin"
        // Android Settings is NOT allowed while locked. Read First's own buttons
        // that open Settings briefly allow it (see Prefs.arm).
    )

    fun build(c: Context): Set<String> {
        val pm = c.packageManager
        val result = HashSet<String>(known)
        result += c.packageName
        result += Prefs.bibleApps(c)

        fun addAll(intent: Intent) {
            pm.queryIntentActivities(intent, 0).forEach { result += it.activityInfo.packageName }
        }

        // Home screen(s) must stay reachable.
        addAll(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME))
        // Whatever the user has set as phone, texts and maps.
        addAll(Intent(Intent.ACTION_DIAL, Uri.parse("tel:")))
        addAll(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=cafe")))
        addAll(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")))
        Telephony.Sms.getDefaultSmsPackage(c)?.let { result += it }

        return result
    }

    private val BIBLE_PKGS = setOf(
        "org.jw.jwlibrary.mobile",
        "com.sirma.mobile.bible.android",
        "com.olivetree.bible",
        "org.blueletterbible.blb"
    )

    /** True for Bible apps: known ones, or any app whose name mentions the Bible or scripture. */
    fun isBibleApp(c: Context, pkg: String, label: String? = null): Boolean {
        if (pkg in BIBLE_PKGS) return true
        val n = (label ?: try {
            c.packageManager.getApplicationInfo(pkg, 0).loadLabel(c.packageManager).toString()
        } catch (e: Exception) { "" }).lowercase()
        return n.contains("bible") || n.contains("jw library") || n.contains("scripture")
    }

    /** The user's main Bible app: the first ticked app that is a Bible app, else the first ticked app. */
    fun mainBibleApp(c: Context): String? {
        val ticked = Prefs.bibleApps(c).filter { it != c.packageName }
        return ticked.firstOrNull { isBibleApp(c, it) } ?: ticked.firstOrNull()
    }

    /** Catch-all for third-party keyboards. */
    fun looksLikeKeyboard(pkg: String): Boolean =
        pkg.contains("inputmethod") || pkg.contains("keyboard") || pkg.contains("honeyboard")
}
