package com.biblefirst

import java.time.LocalDate

/** Verse of the day, King James Version (public domain). Works offline. */
object Verses {
    private val list = listOf(
        "My voice shalt thou hear in the morning, O LORD; in the morning will I direct my prayer unto thee, and will look up." to "Psalm 5:3",
        "Thy word is a lamp unto my feet, and a light unto my path." to "Psalm 119:105",
        "It is of the LORD's mercies that we are not consumed, because his compassions fail not. They are new every morning: great is thy faithfulness." to "Lamentations 3:22-23",
        "Cause me to hear thy lovingkindness in the morning; for in thee do I trust: cause me to know the way wherein I should walk; for I lift up my soul unto thee." to "Psalm 143:8",
        "Man shall not live by bread alone, but by every word that proceedeth out of the mouth of God." to "Matthew 4:4",
        "The grass withereth, the flower fadeth: but the word of our God shall stand for ever." to "Isaiah 40:8",
        "Be still, and know that I am God." to "Psalm 46:10",
        "Trust in the LORD with all thine heart; and lean not unto thine own understanding. In all thy ways acknowledge him, and he shall direct thy paths." to "Proverbs 3:5-6",
        "This is the day which the LORD hath made; we will rejoice and be glad in it." to "Psalm 118:24",
        "Thou wilt keep him in perfect peace, whose mind is stayed on thee: because he trusteth in thee." to "Isaiah 26:3",
        "Thy word have I hid in mine heart, that I might not sin against thee." to "Psalm 119:11",
        "But seek ye first the kingdom of God, and his righteousness; and all these things shall be added unto you." to "Matthew 6:33",
        "O satisfy us early with thy mercy; that we may rejoice and be glad all our days." to "Psalm 90:14",
        "The LORD is my shepherd; I shall not want." to "Psalm 23:1",
        "Be careful for nothing; but in every thing by prayer and supplication with thanksgiving let your requests be made known unto God." to "Philippians 4:6",
        "But be ye doers of the word, and not hearers only, deceiving your own selves." to "James 1:22",
        "But his delight is in the law of the LORD; and in his law doth he meditate day and night." to "Psalm 1:2",
        "But they that wait upon the LORD shall renew their strength; they shall mount up with wings as eagles; they shall run, and not be weary; and they shall walk, and not faint." to "Isaiah 40:31",
        "The entrance of thy words giveth light; it giveth understanding unto the simple." to "Psalm 119:130",
        "I am the light of the world: he that followeth me shall not walk in darkness, but shall have the light of life." to "John 8:12",
        "Commit thy way unto the LORD; trust also in him; and he shall bring it to pass." to "Psalm 37:5",
        "And in the morning, rising up a great while before day, he went out, and departed into a solitary place, and there prayed." to "Mark 1:35",
        "Let the words of my mouth, and the meditation of my heart, be acceptable in thy sight, O LORD, my strength, and my redeemer." to "Psalm 19:14",
        "Come unto me, all ye that labour and are heavy laden, and I will give you rest." to "Matthew 11:28",
        "O taste and see that the LORD is good: blessed is the man that trusteth in him." to "Psalm 34:8",
        "Thou wilt shew me the path of life: in thy presence is fulness of joy; at thy right hand there are pleasures for evermore." to "Psalm 16:11",
        "And the light shineth in darkness; and the darkness comprehended it not." to "John 1:5",
        "Evening, and morning, and at noon, will I pray, and cry aloud: and he shall hear my voice." to "Psalm 55:17"
    )

    fun forDay(dayKey: String): Pair<String, String> {
        val n = try { LocalDate.parse(dayKey).dayOfYear } catch (e: Exception) { 0 }
        return list[n % list.size]
    }
}
