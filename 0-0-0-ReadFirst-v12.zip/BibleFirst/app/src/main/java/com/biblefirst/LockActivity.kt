package com.biblefirst

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.provider.Telephony
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** The calm "reading first" screen shown over any blocked app until today's reading is done. */
class LockActivity : Activity() {

    private var timer: CountDownTimer? = null

    private fun Int.dp() = Ui.dp(this@LockActivity, this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.styleWindow(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        if (!Prefs.isLocked(this)) {
            finish()
            return
        }
        buildUi()
        // Came from the floating "I've finished reading" button: go straight to the check-in.
        if (intent?.getBooleanExtra(EXTRA_CHECKIN, false) == true) {
            intent.removeExtra(EXTRA_CHECKIN)
            confirmDone()
        }
    }

    companion object {
        const val EXTRA_CHECKIN = "checkin"
    }

    @Deprecated("Back goes to the home screen, not to the blocked app")
    override fun onBackPressed() {
        leaveToHome()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24.dp(), 40.dp(), 24.dp(), 24.dp())
        }

        // Greeting and date
        val now = LocalDateTime.now()
        val greeting = when (now.hour) {
            in 0..11 -> "Good morning"
            in 12..16 -> "Good afternoon"
            else -> "Good evening"
        }
        root.addView(Ui.label(this, now.format(DateTimeFormatter.ofPattern("EEEE d MMMM", Locale.getDefault()))))
        root.addView(Ui.text(this, greeting, 32f, serif = true, bold = true), Ui.lp(this, 4))
        root.addView(
            Ui.text(this, "Start with God's word. Your phone will be here when you're done.", 16f, Ui.BODY),
            Ui.lp(this, 4)
        )

        root.addView(streakCard(), Ui.lp(this, 20))
        root.addView(verseCard(), Ui.lp(this, 14))

        // Today's reading (built in), or your own Bible app
        root.addView(
            Ui.button(this, "Start today's reading", filled = true, icon = R.drawable.ic_book) {
                ReadingActivity.open(this)
            },
            Ui.lp(this, 20)
        )
        val bible = AllowList.mainBibleApp(this)
        val open = bible?.let { packageManager.getLaunchIntentForPackage(it) }
        if (bible != null && open != null) {
            root.addView(
                Ui.button(this, "Open ${appName(bible)}", filled = false) { startActivity(open) },
                Ui.lp(this, 10)
            )
        }

        root.addView(
            Ui.button(this, "I've finished my reading", filled = false, icon = R.drawable.ic_check) { confirmDone() },
            Ui.lp(this, 10)
        )

        // Always available
        root.addView(Ui.text(this, "Always available", 13f, Ui.MUTED, bold = true).apply {
            gravity = Gravity.CENTER
        }, Ui.lp(this, 28))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(tile(R.drawable.ic_phone, "Phone") {
            openAllowed(Intent(Intent.ACTION_DIAL, Uri.parse("tel:")))
        })
        row.addView(tile(R.drawable.ic_message, "Texts") { openTexts() })
        row.addView(tile(R.drawable.ic_map, "Maps") {
            openAllowed(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")))
        })
        root.addView(row, Ui.lp(this, 8))

        // Emergency override (deliberately quiet)
        val overrideBtn = Ui.link(this, "Emergency override", Ui.RED) {}
        overrideBtn.setOnClickListener { startOverrideCountdown(overrideBtn) }
        root.addView(overrideBtn, Ui.lp(this, 16))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isFillViewport = true
            addView(root)
        })
    }

    private fun streakCard(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Ui.shape(this@LockActivity, Ui.CARD, 16, Ui.BORDER)
            setPadding(16.dp(), 14.dp(), 16.dp(), 14.dp())
        }
        val icon = ImageView(this).apply {
            setImageDrawable(Ui.tint(this@LockActivity, R.drawable.ic_sun, Ui.ACCENT))
            background = Ui.shape(this@LockActivity, Ui.TINT, 20)
            scaleType = ImageView.ScaleType.CENTER
        }
        card.addView(icon, LinearLayout.LayoutParams(40.dp(), 40.dp()))

        val streak = Prefs.streak(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12.dp(), 0, 8.dp(), 0)
        }
        col.addView(Ui.text(this, if (streak > 0) "$streak-day streak" else "Start your streak", 17f, bold = true))
        col.addView(
            Ui.text(this, if (streak > 0) "Read today to make it ${streak + 1}" else "Read today to begin", 13f, Ui.MUTED)
        )
        card.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        // Last 7 days
        val dots = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val done = Prefs.doneDays(this)
        val today = LocalDate.parse(Prefs.dayKey(this))
        for (i in 6 downTo 0) {
            val key = today.minusDays(i.toLong()).toString()
            val dot = View(this).apply {
                background = if (key in done) Ui.shape(this@LockActivity, Ui.ACCENT, 4)
                else Ui.shape(this@LockActivity, Ui.CARD, 4, Ui.ACCENT, 2)
            }
            dots.addView(dot, LinearLayout.LayoutParams(8.dp(), 8.dp()).apply { marginStart = 4.dp() })
        }
        dots.contentDescription = "Reading days this week"
        card.addView(dots)
        return card
    }

    private fun verseCard(): View {
        val (verse, ref) = Verses.forDay(Prefs.dayKey(this))
        val card = Ui.card(this, 20)
        card.addView(Ui.label(this, "Verse of the day"))
        card.addView(Ui.text(this, "“$verse”", 19f, Ui.TEXT, serif = true, italic = true), Ui.lp(this, 10))
        card.addView(Ui.text(this, "$ref (KJV)", 14f, Ui.BODY, bold = true), Ui.lp(this, 10))
        return card
    }

    private fun tile(icon: Int, label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 13f
        setTextColor(Ui.TEXT)
        stateListAnimator = null
        background = Ui.shape(this@LockActivity, Ui.CARD, 14, Ui.BORDER)
        setCompoundDrawablesRelativeWithIntrinsicBounds(null, Ui.tint(this@LockActivity, icon, Ui.ACCENT), null, null)
        compoundDrawablePadding = 4.dp()
        setPadding(4.dp(), 12.dp(), 4.dp(), 10.dp())
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(0, 76.dp(), 1f).apply {
            marginStart = 4.dp()
            marginEnd = 4.dp()
        }
    }

    private fun appName(pkg: String): String = try {
        packageManager.getApplicationInfo(pkg, 0).loadLabel(packageManager).toString()
    } catch (e: Exception) {
        "Bible app"
    }

    private fun confirmDone() {
        CheckIn.show(this) { finish() }
    }

    /** 60-second wait, then 10 minutes of normal phone use. */
    private fun startOverrideCountdown(btn: Button) {
        timer?.cancel()
        btn.isEnabled = false
        timer = object : CountDownTimer(60_000, 1_000) {
            override fun onTick(msLeft: Long) {
                btn.text = "Unlocking in ${msLeft / 1000}s (leave this screen to cancel)"
            }

            override fun onFinish() {
                Prefs.grantOverride(this@LockActivity, 10)
                finish()
            }
        }.start()
    }

    override fun onPause() {
        // Leaving the screen cancels a pending override.
        timer?.cancel()
        super.onPause()
    }

    /** Opens the app that handles this intent, and allows it while locked. */
    private fun openAllowed(i: Intent) {
        Prefs.arm(this)
        val pkg = packageManager
            .resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName
        if (pkg != null && pkg != "android") {
            Prefs.allowTemp(this, pkg)
            i.setPackage(pkg)
        }
        launch(i)
    }

    /** Opens the phone's texting app (tries several ways) and allows it while locked. */
    private fun openTexts() {
        Prefs.arm(this)
        val candidates = ArrayList<String>()
        Telephony.Sms.getDefaultSmsPackage(this)?.let { candidates += it }
        packageManager
            .resolveActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")), PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName?.let { candidates += it }
        candidates += listOf("com.samsung.android.messaging", "com.google.android.apps.messaging")
        for (pkg in candidates.distinct()) {
            if (pkg == "android") continue
            val i = packageManager.getLaunchIntentForPackage(pkg) ?: continue
            Prefs.allowTemp(this, pkg)
            launch(i)
            return
        }
        launch(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING))
    }

    private fun launch(i: Intent) {
        try {
            startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: ActivityNotFoundException) { /* no such app */ }
    }

    private fun leaveToHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }
}
