package com.biblefirst

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** The calm lavender look shared by every screen. */
object Ui {
    val BG = Color.parseColor("#F6F4FA")
    val CARD = Color.WHITE
    val BORDER = Color.parseColor("#E4DEEE")
    val ACCENT = Color.parseColor("#5E4B8B")
    val ACCENT_DARK = Color.parseColor("#47376E")
    val TINT = Color.parseColor("#ECE7F5")
    val TEXT = Color.parseColor("#241E30")
    val MUTED = Color.parseColor("#655D75")
    val BODY = Color.parseColor("#574F66")
    val DIVIDER = Color.parseColor("#EDE8F3")
    val RED = Color.parseColor("#8A3B32")

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun shape(c: Context, fill: Int, radiusDp: Int, stroke: Int? = null, strokeDp: Int = 1) =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(c, radiusDp).toFloat()
            if (stroke != null) setStroke(dp(c, strokeDp), stroke)
        }

    fun text(
        c: Context, s: CharSequence, sp: Float, color: Int = TEXT,
        bold: Boolean = false, serif: Boolean = false, italic: Boolean = false
    ) = TextView(c).apply {
        text = s
        textSize = sp
        setTextColor(color)
        val base = if (serif) Typeface.SERIF else Typeface.SANS_SERIF
        val style = when {
            bold && italic -> Typeface.BOLD_ITALIC
            bold -> Typeface.BOLD
            italic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        }
        typeface = Typeface.create(base, style)
        setLineSpacing(0f, 1.15f)
    }

    fun label(c: Context, s: String) =
        text(c, s.uppercase(), 12f, MUTED, bold = true).apply { letterSpacing = 0.08f }

    fun card(c: Context, padDp: Int = 16) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(c, CARD, 18, BORDER)
        val p = dp(c, padDp)
        setPadding(p, p, p, p)
    }

    fun button(c: Context, s: String, filled: Boolean, icon: Int? = null, onClick: () -> Unit) =
        Button(c).apply {
            text = s
            isAllCaps = false
            textSize = 16f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            stateListAnimator = null
            val fg = if (filled) Color.WHITE else ACCENT_DARK
            setTextColor(fg)
            val bg = if (filled) shape(c, ACCENT, 16) else shape(c, CARD, 16, ACCENT, 2)
            background = RippleDrawable(ColorStateList.valueOf(0x33000000), bg, null)
            minHeight = dp(c, 56)
            minimumHeight = dp(c, 56)
            gravity = Gravity.CENTER
            if (icon != null) {
                val d = c.getDrawable(icon)?.mutate()
                d?.setTint(fg)
                setCompoundDrawablesRelativeWithIntrinsicBounds(d, null, null, null)
                compoundDrawablePadding = dp(c, 10)
                val side = dp(c, 20)
                setPadding(side, 0, side, 0)
            }
            setOnClickListener { onClick() }
        }

    fun link(c: Context, s: String, color: Int, onClick: () -> Unit) = Button(c).apply {
        text = s
        isAllCaps = false
        textSize = 14f
        setTextColor(color)
        paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG
        background = null
        stateListAnimator = null
        minHeight = dp(c, 44)
        minimumHeight = dp(c, 44)
        setOnClickListener { onClick() }
    }

    fun lp(c: Context, topDp: Int = 0, width: Int = ViewGroup.LayoutParams.MATCH_PARENT) =
        LinearLayout.LayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(c, topDp)
        }

    fun divider(c: Context) = View(c).apply {
        setBackgroundColor(DIVIDER)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 1))
    }

    fun tint(c: Context, res: Int, color: Int) = c.getDrawable(res)?.mutate()?.apply { setTint(color) }

    @Suppress("DEPRECATION")
    fun styleWindow(a: Activity) {
        a.window.statusBarColor = BG
        a.window.navigationBarColor = BG
        a.window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
    }
}
