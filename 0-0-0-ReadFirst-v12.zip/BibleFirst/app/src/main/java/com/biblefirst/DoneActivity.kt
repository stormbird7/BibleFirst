package com.biblefirst

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView

/** The last screen: today's reading is confirmed and the phone is free again. */
class DoneActivity : Activity() {

    private fun Int.dp() = Ui.dp(this@DoneActivity, this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.styleWindow(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24.dp(), 64.dp(), 24.dp(), 32.dp())
        }

        // Big tick
        val tick = ImageView(this).apply {
            setImageDrawable(Ui.tint(this@DoneActivity, R.drawable.ic_check, Color.WHITE))
            background = Ui.shape(this@DoneActivity, Ui.ACCENT, 48)
            scaleType = ImageView.ScaleType.CENTER
            scaleX = 1.8f
            scaleY = 1.8f
            contentDescription = "Reading confirmed"
        }
        val tickBox = LinearLayout(this).apply { gravity = Gravity.CENTER }
        tickBox.addView(tick, LinearLayout.LayoutParams(56.dp(), 56.dp()))
        root.addView(tickBox, LinearLayout.LayoutParams(96.dp(), 96.dp()))

        root.addView(Ui.text(this, "Well done!", 34f, serif = true, bold = true).apply {
            gravity = Gravity.CENTER
        }, Ui.lp(this, 24))
        root.addView(Ui.text(this, "Today's reading is done.", 16f, Ui.BODY).apply {
            gravity = Gravity.CENTER
        }, Ui.lp(this, 6))

        // Points
        val pts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = Ui.shape(this@DoneActivity, Ui.TINT, 20)
            setPadding(24.dp(), 14.dp(), 24.dp(), 14.dp())
        }
        pts.addView(Ui.text(this, "+${Prefs.pointsToday(this)} points", 28f, Ui.ACCENT_DARK, bold = true, serif = true).apply {
            gravity = Gravity.CENTER
        })
        val streak = Prefs.streak(this)
        val sub = "Total: ${Prefs.points(this)} points" +
            if (streak > 0) "  ·  $streak-day streak" else ""
        pts.addView(Ui.text(this, sub, 14f, Ui.BODY, bold = true).apply { gravity = Gravity.CENTER }, Ui.lp(this, 2))
        root.addView(pts, Ui.lp(this, 18))

        // What they wrote today
        val entry = Prefs.journal(this).firstOrNull { it.day == Prefs.dayKey(this) }
        if (entry != null && (entry.passage.isNotBlank() || entry.thought.isNotBlank())) {
            val card = Ui.card(this, 18)
            card.addView(Ui.label(this, "Today"))
            if (entry.passage.isNotBlank()) {
                card.addView(Ui.text(this, entry.passage, 18f, Ui.TEXT, bold = true), Ui.lp(this, 6))
            }
            if (entry.thought.isNotBlank()) {
                card.addView(Ui.text(this, entry.thought, 16f, Ui.BODY, serif = true, italic = true), Ui.lp(this, 4))
            }
            root.addView(card, Ui.lp(this, 24))
        }

        root.addView(
            Ui.button(this, "Start my day", filled = true) { leaveToHome() },
            Ui.lp(this, 32)
        )
        root.addView(
            Ui.button(this, "Go to my homepage", filled = false, icon = R.drawable.ic_book) {
                startActivity(
                    Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                finish()
            },
            Ui.lp(this, 10)
        )
        root.addView(Ui.text(this, "See you tomorrow morning.", 14f, Ui.MUTED).apply {
            gravity = Gravity.CENTER
        }, Ui.lp(this, 18))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isFillViewport = true
            addView(root)
        })

        // A badge "Share" choice from the check-in arrives here.
        val share = intent.getIntExtra(EXTRA_SHARE, 0)
        if (share > 0 && savedInstanceState == null) ShareCard.share(this, share)
    }

    @Deprecated("Back also leaves to the home screen")
    override fun onBackPressed() {
        leaveToHome()
    }

    private fun leaveToHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }

    companion object {
        const val EXTRA_SHARE = "share"
    }
}
