package com.biblefirst

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

/**
 * Reading inside Read First. It always starts at the next chapter you haven't read,
 * "Read more" carries on with the next chapter, and finishing saves your place
 * so you never read the same chapter twice.
 */
class ReadingActivity : Activity() {

    private var count = 1 // chapters shown so far
    private var scroll: ScrollView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.styleWindow(this)
        count = savedInstanceState?.getInt("count") ?: 1
        render()
    }

    override fun onSaveInstanceState(out: Bundle) {
        super.onSaveInstanceState(out)
        out.putInt("count", count)
    }

    private fun render() {
        val start = Prefs.readingPos(this)
        val already = Prefs.doneToday(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = Ui.dp(this@ReadingActivity, 20)
            setPadding(pad, Ui.dp(this@ReadingActivity, 36), pad, pad)
        }
        root.addView(Ui.label(this, if (already) "Keep reading" else "Today's reading"))
        root.addView(Ui.text(this, Bible.range(this, start, count), 30f, serif = true, bold = true), Ui.lp(this, 4))

        // Each chapter shown so far
        var pos = start
        for (n in 0 until count) {
            val verses = Bible.chapter(this, pos)
            val card = Ui.card(this, 20)
            card.addView(Ui.label(this, Bible.label(this, pos)))
            verses.forEachIndexed { i, v ->
                card.addView(Ui.text(this, "${i + 1}  $v", 18f, Ui.TEXT, serif = true), Ui.lp(this, 10))
            }
            root.addView(card, Ui.lp(this, if (n == 0) 16 else 12))
            pos = Bible.next(this, pos)
        }

        root.addView(Ui.button(this, "Read more: ${Bible.label(this, pos)}", filled = false) {
            count += 1
            render()
        }, Ui.lp(this, 14))

        // Read anything else in your own Bible app
        val bible = AllowList.mainBibleApp(this)
        val open = bible?.let { packageManager.getLaunchIntentForPackage(it) }
        if (bible != null && open != null) {
            val name = try {
                packageManager.getApplicationInfo(bible, 0).loadLabel(packageManager).toString()
            } catch (e: Exception) { "my Bible app" }
            root.addView(Ui.button(this, "Open $name", filled = false, icon = R.drawable.ic_book) {
                startActivity(open)
            }, Ui.lp(this, 10))
            root.addView(Ui.text(this, "Read anything you like there, then come back here.", 14f, Ui.MUTED),
                Ui.lp(this, 4))
        }

        root.addView(Ui.button(this, "Reading completed today", filled = true, icon = R.drawable.ic_check) {
            val read = Bible.range(this, start, count)
            // Save your place: next time starts after what you just read.
            Prefs.setReadingPos(this, Bible.advance(this, start, count))
            if (already) {
                Prefs.appendJournal(this, read)
                Toast.makeText(this, "Saved. Next time: ${Bible.label(this, Prefs.readingPos(this))}", Toast.LENGTH_LONG).show()
                startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
                finish()
            } else {
                CheckIn.completeDirect(this, read) { finish() }
            }
        }, Ui.lp(this, 24))

        val sv = ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isFillViewport = true
            addView(root)
        }
        val keep = scroll?.scrollY ?: 0
        scroll = sv
        setContentView(sv)
        sv.post { sv.scrollTo(0, keep) }
    }

    companion object {
        fun open(a: Activity) = a.startActivity(Intent(a, ReadingActivity::class.java))
    }
}
