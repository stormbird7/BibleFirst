package com.biblefirst

import android.content.Context
import java.time.LocalDate
import java.time.LocalDateTime

/** All saved settings and the "is the phone locked right now?" rule. */
object Prefs {
    private fun sp(c: Context) =
        c.getSharedPreferences("biblefirst", Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    /** Hour of day (0-12) when a new "reading day" begins and the lock turns on. */
    fun startHour(c: Context) = sp(c).getInt("start_hour", 4)
    fun setStartHour(c: Context, h: Int) =
        sp(c).edit().putInt("start_hour", h.coerceIn(0, 12)).apply()

    /** Minutes before the lock starts to send a reminder notification (0 = off). */
    fun reminderMinutes(c: Context) = sp(c).getInt("reminder_minutes", 30)
    fun setReminderMinutes(c: Context, m: Int) =
        sp(c).edit().putInt("reminder_minutes", m.coerceIn(0, 120)).apply()

    fun bibleApps(c: Context): Set<String> =
        sp(c).getStringSet("bible_apps", emptySet()) ?: emptySet()

    fun setBibleApps(c: Context, s: Set<String>) =
        sp(c).edit().putStringSet("bible_apps", HashSet(s)).apply()

    /** The current "reading day" as a string. Rolls over at the start hour, not midnight. */
    private fun today(c: Context): String =
        LocalDateTime.now().minusHours(startHour(c).toLong()).toLocalDate().toString()

    fun dayKey(c: Context): String = today(c)

    fun doneToday(c: Context) = sp(c).getString("done_day", null) == today(c)

    /** Days of the week the lock runs (1 = Monday ... 7 = Sunday). All days by default. */
    fun lockDays(c: Context): Set<Int> {
        val s = sp(c).getStringSet("lock_days", null) ?: return (1..7).toSet()
        return s.mapNotNull { it.toIntOrNull() }.toSet()
    }

    fun setLockDay(c: Context, day: Int, on: Boolean) {
        val s = lockDays(c).toMutableSet()
        if (on) s += day else s -= day
        sp(c).edit().putStringSet("lock_days", s.map { it.toString() }.toSet()).apply()
    }

    fun isLockDay(c: Context, date: LocalDate) = date.dayOfWeek.value in lockDays(c)

    /** The most recent lock day before [date], so days off don't break a streak. */
    private fun previousLockDay(c: Context, date: LocalDate): String {
        var d = date.minusDays(1)
        for (i in 0 until 7) {
            if (isLockDay(c, d)) return d.toString()
            d = d.minusDays(1)
        }
        return date.minusDays(1).toString()
    }

    val MILESTONES = listOf(3, 7, 14, 30, 50, 100, 365)

    /**
     * Marks today's reading done and updates the streak.
     * Returns the new streak if it went up today, otherwise null.
     */
    fun markDone(c: Context): Int? {
        val t = today(c)
        val p = sp(c)
        val e = p.edit().putString("done_day", t)
        val last = p.getString("streak_day", null)
        var newStreak: Int? = null
        if (last != t) {
            val prev = previousLockDay(c, LocalDate.parse(t))
            val s = if (last == prev) p.getInt("streak", 0) + 1 else 1
            e.putInt("streak", s)
                .putString("streak_day", t)
                .putInt("best", maxOf(s, p.getInt("best", 0)))
            newStreak = s
        }
        val cutoff = LocalDate.parse(t).minusDays(30).toString()
        val days = HashSet(doneDays(c))
        days += t
        e.putStringSet("done_days", days.filter { it >= cutoff }.toSet())
        e.apply()
        return newStreak
    }

    /** The streak number to celebrate, if [streak] just reached a milestone. */
    fun milestoneFor(streak: Int?): Int? = if (streak != null && streak in MILESTONES) streak else null

    fun privacyAccepted(c: Context) = sp(c).getBoolean("privacy_ok", false)
    fun setPrivacyAccepted(c: Context) = sp(c).edit().putBoolean("privacy_ok", true).apply()

    fun clearDone(c: Context) {
        val days = HashSet(doneDays(c))
        days -= today(c)
        sp(c).edit().remove("done_day").putStringSet("done_days", days).apply()
    }

    fun doneDays(c: Context): Set<String> =
        sp(c).getStringSet("done_days", emptySet()) ?: emptySet()

    /** Days in a row, still "on" if the last reading was today or the previous lock day. */
    fun streak(c: Context): Int {
        val t = today(c)
        val last = sp(c).getString("streak_day", null) ?: return 0
        val prev = previousLockDay(c, LocalDate.parse(t))
        return if (last == t || last >= prev) sp(c).getInt("streak", 0) else 0
    }

    fun bestStreak(c: Context) = sp(c).getInt("best", 0)

    fun setupDone(c: Context) = sp(c).getBoolean("setup_done", false)
    fun setSetupDone(c: Context, v: Boolean) = sp(c).edit().putBoolean("setup_done", v).apply()

    fun bibleAutoPicked(c: Context) = sp(c).getBoolean("bible_auto_picked", false)
    fun setBibleAutoPicked(c: Context) = sp(c).edit().putBoolean("bible_auto_picked", true).apply()

    fun overrideActive(c: Context) =
        System.currentTimeMillis() < sp(c).getLong("override_until", 0L)

    fun overrideCount(c: Context) = sp(c).getInt("override_count", 0)

    fun grantOverride(c: Context, minutes: Int) {
        sp(c).edit()
            .putLong("override_until", System.currentTimeMillis() + minutes * 60_000L)
            .putInt("override_count", overrideCount(c) + 1)
            .apply()
    }

    /** Apps opened from the "Always available" buttons are allowed for a while. */
    fun allowTemp(c: Context, pkg: String, minutes: Int = 30) {
        val now = System.currentTimeMillis()
        val old = sp(c).getStringSet("temp_allowed", emptySet()) ?: emptySet()
        val keep = HashSet<String>()
        for (e in old) {
            val p = e.split("|")
            if (p.size == 2 && p[0] != pkg && (p[1].toLongOrNull() ?: 0L) > now) keep += e
        }
        keep += "$pkg|${now + minutes * 60_000L}"
        sp(c).edit().putStringSet("temp_allowed", keep).apply()
    }

    fun tempAllowed(c: Context, pkg: String): Boolean {
        val now = System.currentTimeMillis()
        val set = sp(c).getStringSet("temp_allowed", emptySet()) ?: emptySet()
        return set.any {
            val p = it.split("|")
            p.size == 2 && p[0] == pkg && (p[1].toLongOrNull() ?: 0L) > now
        }
    }

    /** Short grace period after tapping Phone / Texts / Maps: any app that opens is allowed. */
    fun arm(c: Context, seconds: Int = 8) =
        sp(c).edit().putLong("armed_until", System.currentTimeMillis() + seconds * 1000L).apply()

    fun armed(c: Context) = System.currentTimeMillis() < sp(c).getLong("armed_until", 0L)

    fun setLastBlocked(c: Context, pkg: String) =
        sp(c).edit().putString("last_blocked", pkg).apply()

    fun lastBlocked(c: Context): String = sp(c).getString("last_blocked", "") ?: ""

    // ---------- Reading plan: where you are in the Bible ----------

    fun plan(c: Context): String = sp(c).getString("plan", Bible.PLAN_NT) ?: Bible.PLAN_NT

    /** Choosing a different plan starts it from its first chapter. */
    fun setPlan(c: Context, plan: String) {
        if (plan == plan(c) && sp(c).contains("pos_book")) return
        val p = Bible.planStart(plan)
        sp(c).edit().putString("plan", plan).putInt("pos_book", p.book).putInt("pos_chapter", p.chapter).apply()
    }

    /** The next chapter you haven't read yet. */
    fun readingPos(c: Context): Bible.Pos {
        val start = Bible.planStart(plan(c))
        return Bible.Pos(sp(c).getInt("pos_book", start.book), sp(c).getInt("pos_chapter", start.chapter))
    }

    fun setReadingPos(c: Context, p: Bible.Pos) =
        sp(c).edit().putInt("pos_book", p.book).putInt("pos_chapter", p.chapter).apply()

    /** Adds more reading to today's journal entry (or starts one). */
    fun appendJournal(c: Context, passage: String) {
        val today = journal(c).firstOrNull { it.day == today(c) }
        if (today == null) addJournal(c, passage, "")
        else addJournal(c, if (today.passage.isBlank()) passage else "${today.passage}, $passage", today.thought)
    }

    // ---------- Points ----------
    // 10 for reading, +1 per streak day (up to +20), +5 for a journal note, +50 for a new badge.

    fun points(c: Context) = sp(c).getInt("points", 0)
    fun pointsToday(c: Context) =
        if (sp(c).getString("points_day", null) == today(c)) sp(c).getInt("points_today", 0) else 0

    /** Awards today's points once. Returns the points earned. */
    fun awardPoints(c: Context, streak: Int, wroteNote: Boolean, newBadge: Boolean): Int {
        if (sp(c).getString("points_day", null) == today(c)) return pointsToday(c)
        val p = 10 + minOf(streak, 20) + (if (wroteNote) 5 else 0) + (if (newBadge) 50 else 0)
        sp(c).edit()
            .putInt("points", points(c) + p)
            .putInt("points_today", p)
            .putString("points_day", today(c))
            .apply()
        return p
    }

    /** "Start tomorrow" during setup: no lock for the rest of today. */
    fun skipToday(c: Context) = sp(c).edit().putString("skip_day", today(c)).apply()
    fun clearSkip(c: Context) = sp(c).edit().remove("skip_day").apply()
    fun skippedToday(c: Context) = sp(c).getString("skip_day", null) == today(c)

    fun isLocked(c: Context) =
        enabled(c) && isLockDay(c, LocalDate.parse(today(c))) && !doneToday(c) &&
            !overrideActive(c) && !skippedToday(c)

    // ---------- Reading journal ----------

    data class Entry(val day: String, val passage: String, val thought: String)

    fun addJournal(c: Context, passage: String, thought: String) {
        if (passage.isBlank() && thought.isBlank()) return
        val t = today(c)
        val arr = org.json.JSONArray(sp(c).getString("journal", "[]"))
        val out = org.json.JSONArray()
        // One entry per day: replace today's if it exists.
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("day") != t) out.put(o)
        }
        out.put(org.json.JSONObject().put("day", t).put("passage", passage.trim()).put("thought", thought.trim()))
        sp(c).edit().putString("journal", out.toString()).apply()
    }

    /** Newest first. */
    fun journal(c: Context): List<Entry> {
        val arr = try {
            org.json.JSONArray(sp(c).getString("journal", "[]"))
        } catch (e: Exception) {
            org.json.JSONArray()
        }
        val list = ArrayList<Entry>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            list += Entry(o.optString("day"), o.optString("passage"), o.optString("thought"))
        }
        return list.sortedByDescending { it.day }
    }
}
