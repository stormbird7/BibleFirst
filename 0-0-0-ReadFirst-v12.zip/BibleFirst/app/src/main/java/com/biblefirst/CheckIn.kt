package com.biblefirst

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout

/** The "I've finished my reading" check-in, plus the milestone celebration. */
object CheckIn {

    /** Asks what was read, saves it, marks the day done, then calls [after]. */
    fun show(a: Activity, after: () -> Unit) {
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            val p = Ui.dp(a, 20)
            setPadding(p, Ui.dp(a, 8), p, 0)
        }
        box.addView(Ui.text(a, "What did you read?", 15f, Ui.TEXT, bold = true))
        val passage = field(a, "e.g. John 3 or Psalm 23")
        box.addView(passage)
        box.addView(Ui.text(a, "One thought to carry today (optional)", 15f, Ui.TEXT, bold = true), Ui.lp(a, 14))
        val thought = field(a, "e.g. God is with me today").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            minLines = 2
        }
        box.addView(thought)

        AlertDialog.Builder(a)
            .setTitle("Have you finished today's reading?")
            .setView(box)
            .setPositiveButton("Yes, save") { _, _ ->
                Prefs.addJournal(a, passage.text.toString(), thought.text.toString())
                val wrote = passage.text.isNotBlank() || thought.text.isNotBlank()
                val streak = Prefs.markDone(a)
                val milestone = Prefs.milestoneFor(streak)
                Prefs.awardPoints(a, Prefs.streak(a), wrote, milestone != null)
                if (milestone != null) celebrate(a, milestone, after) else finishFlow(a, 0, after)
            }
            .setNegativeButton("Not yet", null)
            .show()
    }

    /** "Reading completed today" from the built-in reading: no questions, straight to Well done. */
    fun completeDirect(a: Activity, passage: String, after: () -> Unit) {
        Prefs.addJournal(a, passage, "")
        val streak = Prefs.markDone(a)
        val milestone = Prefs.milestoneFor(streak)
        Prefs.awardPoints(a, Prefs.streak(a), false, milestone != null)
        if (milestone != null) celebrate(a, milestone, after) else finishFlow(a, 0, after)
    }

    private fun field(a: Activity, hint: String) = EditText(a).apply {
        this.hint = hint
        textSize = 16f
        setTextColor(Ui.TEXT)
        setHintTextColor(Ui.MUTED)
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
    }

    fun badgeName(days: Int) = when (days) {
        3 -> "First steps"
        7 -> "One week"
        14 -> "Two weeks"
        30 -> "One month"
        50 -> "Fifty days"
        100 -> "Hundred days"
        365 -> "One whole year"
        else -> "$days days"
    }

    private fun celebrate(a: Activity, days: Int, after: () -> Unit) {
        AlertDialog.Builder(a)
            .setTitle("New badge: ${badgeName(days)}")
            .setMessage("You've read first for $days days in a row. Well done! Share it to encourage a friend?")
            .setPositiveButton("Share") { _, _ -> finishFlow(a, days, after) }
            .setNegativeButton("Done") { _, _ -> finishFlow(a, 0, after) }
            .setOnCancelListener { finishFlow(a, 0, after) }
            .show()
    }

    /** Shows the "Reading done" screen (which shares the badge if asked), then runs [after]. */
    private fun finishFlow(a: Activity, shareDays: Int, after: () -> Unit) {
        a.startActivity(Intent(a, DoneActivity::class.java).putExtra(DoneActivity.EXTRA_SHARE, shareDays))
        after()
    }
}
