package com.biblefirst

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * Watches which app comes to the front. While the phone is locked, anything that
 * isn't on the allow-list is covered by the reading screen (LockActivity).
 * While you're in your Bible app, a small "I've finished reading" button floats on top.
 */
class LockService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var allow: Set<String> = emptySet()
    private var allowBuiltAt = 0L
    private var lastPkg: String? = null
    private val activityCache = HashMap<String, Boolean>()
    private val bibleCache = HashMap<String, Boolean>()
    private var pill: View? = null

    // Re-check every few seconds so an expired override or a new morning
    // takes effect even if the user stays inside the same app.
    private val recheck = object : Runnable {
        override fun run() {
            lastPkg?.let {
                enforce(it)
                updatePill(it)
            }
            handler.postDelayed(this, 5_000)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        allowBuiltAt = 0L
        handler.removeCallbacks(recheck)
        handler.postDelayed(recheck, 5_000)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        // Only real app screens count. Pop-ups, bubbles, toasts and panels from
        // other apps are ignored, so they can't throw you out of Messages or Maps.
        if (!isFullScreenApp(pkg, event.className?.toString())) return
        lastPkg = pkg
        enforce(pkg)
        updatePill(pkg)
    }

    private fun isFullScreenApp(pkg: String, cls: String?): Boolean {
        if (cls.isNullOrEmpty()) return false
        val key = "$pkg/$cls"
        return activityCache.getOrPut(key) {
            try {
                packageManager.getActivityInfo(ComponentName(pkg, cls), 0)
                true
            } catch (e: Exception) {
                false
            }
        }
    }

    private fun enforce(pkg: String) {
        if (!Prefs.isLocked(this)) return
        if (System.currentTimeMillis() - allowBuiltAt > 30_000) {
            allow = AllowList.build(this)
            allowBuiltAt = System.currentTimeMillis()
        }
        if (pkg in allow || AllowList.looksLikeKeyboard(pkg) || Prefs.tempAllowed(this, pkg)) return
        // Just tapped Phone / Texts / Maps: whatever opens next is allowed.
        if (Prefs.armed(this)) {
            Prefs.allowTemp(this, pkg, 10)
            return
        }
        Prefs.setLastBlocked(this, pkg)

        startActivity(
            Intent(this, LockActivity::class.java).addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            )
        )
    }

    // ---------- Floating "I've finished reading" button ----------

    private fun updatePill(pkg: String) {
        val inBible = pkg in Prefs.bibleApps(this) &&
            bibleCache.getOrPut(pkg) { AllowList.isBibleApp(this, pkg) }
        if (Prefs.isLocked(this) && inBible) showPill() else hidePill()
    }

    private fun showPill() {
        if (pill != null) return
        val btn = Ui.button(this, "I've finished reading", filled = true, icon = R.drawable.ic_check) {
            hidePill()
            startActivity(
                Intent(this, LockActivity::class.java)
                    .putExtra(LockActivity.EXTRA_CHECKIN, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            )
        }.apply {
            elevation = Ui.dp(this@LockService, 8).toFloat()
            minWidth = 0
            minimumWidth = 0
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = Ui.dp(this@LockService, 96)
        }
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(btn, lp)
            pill = btn
        } catch (e: Exception) {
            pill = null
        }
    }

    private fun hidePill() {
        val p = pill ?: return
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(p)
        } catch (e: Exception) { /* already gone */ }
        pill = null
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        hidePill()
        handler.removeCallbacks(recheck)
        super.onDestroy()
    }
}
