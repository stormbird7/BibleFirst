package com.biblefirst

import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.io.File
import java.io.FileOutputStream

/** Draws a lavender streak picture and opens the share menu (Instagram, WhatsApp...). */
object ShareCard {

    fun share(a: Activity, days: Int) {
        try {
            val file = draw(a, days)
            val uri = Uri.parse("content://${ShareProvider.AUTHORITY}/${file.name}")
            val send = Intent(Intent.ACTION_SEND)
                .setType("image/png")
                .putExtra(Intent.EXTRA_STREAM, uri)
                .putExtra(Intent.EXTRA_TEXT, "I've read the Bible first thing for $days days in a row with Read First.")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            send.clipData = ClipData.newRawUri("streak", uri)
            a.startActivity(Intent.createChooser(send, "Share your streak").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) {
            // Sharing is a bonus; never crash over it.
        }
    }

    private fun draw(a: Activity, days: Int): File {
        val w = 1080
        val h = 1350
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Ui.BG)

        val card = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.ACCENT }
        c.drawRoundRect(RectF(80f, 80f, (w - 80).toFloat(), (h - 80).toFloat()), 64f, 64f, card)

        val center = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
        }
        center.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        center.textSize = 44f
        center.letterSpacing = 0.12f
        c.drawText("READ FIRST", w / 2f, 260f, center)

        center.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        center.letterSpacing = 0f
        center.textSize = 300f
        c.drawText("$days", w / 2f, 640f, center)

        center.textSize = 72f
        c.drawText(if (days == 1) "day in a row" else "days in a row", w / 2f, 760f, center)

        center.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        center.textSize = 44f
        center.color = Color.parseColor("#E4DEEE")
        c.drawText("Bible reading before scrolling", w / 2f, 850f, center)

        // Verse at the bottom
        val (verse, ref) = Verses.forDay(Prefs.dayKey(a))
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 38f
            typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
        }
        val textW = w - 320
        @Suppress("DEPRECATION")
        val layout = StaticLayout(
            "“$verse” — $ref", tp, textW, Layout.Alignment.ALIGN_CENTER, 1.2f, 0f, false
        )
        c.save()
        c.translate(160f, 960f)
        layout.draw(c)
        c.restore()

        val dir = File(a.cacheDir, "share").apply { mkdirs() }
        val file = File(dir, "streak.png")
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
        return file
    }
}
