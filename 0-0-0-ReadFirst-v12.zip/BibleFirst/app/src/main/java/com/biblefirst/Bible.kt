package com.biblefirst

import android.content.Context

/**
 * The whole King James Bible (public domain), built into the app.
 * assets/bible/books.txt lists "Name|chapters"; assets/bible/<n>.txt holds one book,
 * chapters separated by a blank line and one verse per line.
 */
object Bible {

    class Book(val index: Int, val name: String, val chapters: Int)

    /** A place in the Bible: book index and chapter index (both from 0). */
    data class Pos(val book: Int, val chapter: Int)

    private var books: List<Book>? = null
    private var cachedBook = -1
    private var cachedChapters: List<List<String>> = emptyList()

    fun books(c: Context): List<Book> {
        books?.let { return it }
        val list = c.assets.open("bible/books.txt").bufferedReader(Charsets.UTF_8).readLines()
            .filter { it.isNotBlank() }
            .mapIndexed { i, line ->
                val parts = line.split("|")
                Book(i, parts[0], parts[1].trim().toInt())
            }
        books = list
        return list
    }

    /** The verses of one chapter. */
    fun chapter(c: Context, pos: Pos): List<String> {
        if (cachedBook != pos.book) {
            val text = c.assets.open("bible/${pos.book}.txt").bufferedReader(Charsets.UTF_8).readText()
            cachedChapters = text.split("\n\n").map { ch -> ch.split("\n").filter { it.isNotBlank() } }
            cachedBook = pos.book
        }
        return cachedChapters.getOrElse(pos.chapter) { emptyList() }
    }

    /** The chapter after [pos]; after Revelation it starts again at Genesis. */
    fun next(c: Context, pos: Pos): Pos {
        val b = books(c)
        return if (pos.chapter + 1 < b[pos.book].chapters) Pos(pos.book, pos.chapter + 1)
        else Pos((pos.book + 1) % b.size, 0)
    }

    fun advance(c: Context, pos: Pos, count: Int): Pos {
        var p = pos
        repeat(count) { p = next(c, p) }
        return p
    }

    fun label(c: Context, pos: Pos): String {
        val name = books(c)[pos.book].name
        return "${if (name == "Psalms") "Psalm" else name} ${pos.chapter + 1}"
    }

    /** "Matthew 1", "Matthew 1-3" or "Matthew 28 - Mark 1". */
    fun range(c: Context, start: Pos, count: Int): String {
        if (count <= 1) return label(c, start)
        val end = advance(c, start, count - 1)
        return if (end.book == start.book) "${books(c)[start.book].name} ${start.chapter + 1}-${end.chapter + 1}"
        else "${label(c, start)} - ${label(c, end)}"
    }

    // Where each reading plan begins.
    const val PLAN_NT = "nt"       // Matthew 1
    const val PLAN_PSALMS = "ps"   // Psalms 1
    const val PLAN_START = "ot"    // Genesis 1

    fun planStart(plan: String): Pos = when (plan) {
        PLAN_PSALMS -> Pos(18, 0)
        PLAN_START -> Pos(0, 0)
        else -> Pos(39, 0)
    }
}
