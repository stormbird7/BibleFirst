package com.biblefirst

import android.app.Activity
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Past check-ins: what was read and the thought for the day. */
class JournalActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.styleWindow(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = Ui.dp(this@JournalActivity, 20)
            setPadding(p, Ui.dp(this@JournalActivity, 36), p, p)
        }
        root.addView(Ui.link(this, "← Back", Ui.ACCENT_DARK) { finish() },
            Ui.lp(this, 0, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(Ui.text(this, "My reading journal", 28f, serif = true, bold = true), Ui.lp(this, 4))

        val entries = Prefs.journal(this)
        root.addView(
            Ui.text(
                this,
                if (entries.isEmpty()) "Nothing here yet. After your reading, tap I've finished and note what you read."
                else "${entries.size} ${if (entries.size == 1) "entry" else "entries"}. Newest first.",
                15f, Ui.BODY
            ),
            Ui.lp(this, 6)
        )

        val fmt = DateTimeFormatter.ofPattern("EEEE d MMMM yyyy", Locale.getDefault())
        for (e in entries) {
            val card = Ui.card(this)
            val date = try { LocalDate.parse(e.day).format(fmt) } catch (x: Exception) { e.day }
            card.addView(Ui.label(this, date))
            if (e.passage.isNotBlank()) {
                card.addView(Ui.text(this, e.passage, 18f, Ui.TEXT, bold = true), Ui.lp(this, 6))
            }
            if (e.thought.isNotBlank()) {
                card.addView(Ui.text(this, e.thought, 16f, Ui.BODY, serif = true, italic = true), Ui.lp(this, 4))
            }
            root.addView(card, Ui.lp(this, 12))
        }

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isFillViewport = true
            addView(root)
        })
    }
}
